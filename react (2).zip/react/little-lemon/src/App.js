// src/App.js
import React, { useState } from 'react';
import Header from './components/Header';
import Menu from './components/Menu';
import BookTable from './components/BookTable.js';
import Footer from './components/Footer';
import './style.css';

function App() {
  const [menuItems] = useState([
    { id: 1, name: 'Noodle Delight', description: 'Freshly crafted noodles with vibrant vegetables.', price: '$12.99' },
    { id: 2, name: 'Garden Salad', description: 'A fresh mix of organic greens with a light vinaigrette.', price: '$8.99' },
    { id: 3, name: 'Lemon Chicken', description: 'Tender chicken breast with a tangy lemon sauce.', price: '$14.99' },
  ]);

  return (
    <div>
      <Header />
      <main>
        <Menu items={menuItems} />
        <BookTable />
      </main>
      <Footer />
    </div>
  );
}

export default App;
