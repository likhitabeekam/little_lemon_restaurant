import React, { useState } from "react";

const BookingForm = ({ availableTimes, handleSubmit }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [guests, setGuests] = useState("");
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    let formErrors = {};
    if (!name) formErrors.name = "Name is required";
    if (!email || !/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) formErrors.email = "Valid email is required";
    if (!date) formErrors.date = "Date is required";
    if (!time) formErrors.time = "Time is required";
    if (!guests || guests <= 0) formErrors.guests = "At least 1 guest is required";

    return formErrors;
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const formErrors = validateForm();
    if (Object.keys(formErrors).length === 0) {
      handleSubmit({ name, email, date, time, guests });
    } else {
      setErrors(formErrors);
    }
  };

  return (
    <form className="booking-form" onSubmit={onSubmit}>
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      {errors.name && <span className="error">{errors.name}</span>}
      
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      {errors.email && <span className="error">{errors.email}</span>}

      <input
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
      />
      {errors.date && <span className="error">{errors.date}</span>}

      <select value={time} onChange={(e) => setTime(e.target.value)}>
        <option value="">Select a time</option>
        {availableTimes.map((availableTime) => (
          <option key={availableTime} value={availableTime}>
            {availableTime}
          </option>
        ))}
      </select>
      {errors.time && <span className="error">{errors.time}</span>}

      <input
        type="number"
        placeholder="Guests"
        value={guests}
        onChange={(e) => setGuests(e.target.value)}
        min="1"
      />
      {errors.guests && <span className="error">{errors.guests}</span>}

      <button type="submit">Book Table</button>
    </form>
  );
};

export default BookingForm;
