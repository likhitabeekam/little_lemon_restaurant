// src/components/Header.js
import React from 'react';

function Header() {
  return (
    <header>
      <div className="header-content">
        <img src="Asset 14@4x.png" alt="Little Lemon Restaurant Logo" className="logo" />
        <nav className="nav-menu">
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#menu">Menu</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#book">Book</a></li>
            <li><a href="#contact">Contact Us</a></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;
