// src/components/Menu.js
import React from 'react';

function Menu({ items }) {
  return (
    <section id="menu">
      <h2>Our Menu</h2>
      <div className="menu-list">
        {items.map(item => (
          <div key={item.id} className="menu-item">
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <span>{item.price}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Menu;
